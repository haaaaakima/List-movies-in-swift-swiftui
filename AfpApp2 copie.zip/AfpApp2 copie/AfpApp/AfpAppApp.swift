import SwiftUI

@main
struct AfpAppApp: App {
    var body: some Scene {
        WindowGroup {
            LandingScreenView()
        }
    }
}
