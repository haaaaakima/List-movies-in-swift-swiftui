import SwiftUI

struct Category: Identifiable {
    var id = UUID()
    var name: String
    var image: String
    var backgroundColor: Color
    var movies: [Movie]
}

// Génération automatique des catégories
var categories: [Category] {
    // Styles des catégories (nom, image, couleur)
    let categoryStyles: [String: (image: String, color: Color)] = [
        "Film": ("titanic", .blue),
        "Manga": ("naruto", .orange),
        "Série": ("breakingbad", .green),
        "Animation": ("simpsons", .purple),
        "Drama Coréen": ("crashlandingonyou", .red)
    ]

    // Groupement des films par catégorie
    let groupedMovies = Dictionary(grouping: movies, by: { $0.category })

    // Création dynamique des catégories
    return groupedMovies.compactMap { (categoryName, movies) in
        guard let style = categoryStyles[categoryName] else { return nil }
        return Category(
            name: categoryName,
            image: style.image,
            backgroundColor: style.color,
            movies: movies
        )
    }
}
