/* import SwiftUI

struct CategoryView: View {
    var body: some View {
        NavigationStack {
            List(categories) { category in
                NavigationLink(destination: DetailCategoryView(category: category)) {
                    HStack {
                        ZStack {
                            category.backgroundColor
                                .frame(width: 50, height: 50)
                                .cornerRadius(10)

                            Image(category.image)
                                .resizable()
                                .frame(width: 40, height: 40)
                        }

                        Text(category.name)
                            .fontWeight(.bold)
                            .padding(.leading, 10)
                    }
                    .padding(.vertical, 5)
                }
            }
            .navigationTitle("Catégories")
        }
    }
}

struct CategoryView_Previews: PreviewProvider {
    static var previews: some View {
        CategoryView()
    }
}
*/

 import SwiftUI

 struct CategoryView: View {
     var body: some View {
         NavigationStack {
             ScrollView {
                 ForEach(categories) { category in
                     NavigationLink(destination: DetailCategoryView(category: category)) {
                         HStack {
                             ZStack {
                                 category.backgroundColor
                                     .frame(width: 50, height: 50)
                                     .cornerRadius(10)
                                 
                                 Image(category.image)
                                     .resizable()
                                     .frame(width: 40, height: 40)
                             }
                             
                             Text(category.name)
                                 .fontWeight(.bold)
                                 .foregroundColor(Color.black)
                                 .padding(.leading, 10)
                             
                             Spacer()
                             
                             Image(systemName: "chevron.right")
                                 .foregroundColor(Color.gray.opacity(0.6)) // Gris plus clair
                                 .padding(.trailing, 10)
                         } // HStack
                         .padding(.horizontal, 15)
                         .padding(.vertical, 8)
                         
                             .padding(.leading, 15)
                     } // NavigationLink
                     Divider()

                 }
             }
             .navigationTitle("Catégories")
         } // NavigationStack
     }
 }

 struct CategoryView_Previews: PreviewProvider {
     static var previews: some View {
         CategoryView()
     }
 }

