import SwiftUI

struct DetailCategoryView: View {
    var category: Category

    var body: some View {
        VStack {
            List(category.movies) { movie in
                NavigationLink(destination: DetailMovieView(movie: movie)) {
                    HStack {
                        ZStack {
                            movie.backgroundColor
                                .frame(width: 50, height: 50)
                                .cornerRadius(10)

                            Image(movie.image)
                                .resizable()
                                .frame(width: 40, height: 40)
                        }

                        Text(movie.name)
                            .fontWeight(.bold)
                            .padding(.leading, 10)
                    }
                }
            }
            .navigationTitle(category.name)
        }
    }
}

struct DetailCategoryView_Previews: PreviewProvider {
    static var previews: some View {
        DetailCategoryView(category: categories.first!)
    }
}
