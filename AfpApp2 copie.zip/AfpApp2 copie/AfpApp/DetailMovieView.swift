/*import Foundation
import SwiftUI

struct DetailMovieView: View {
    var movie: Movie

    var body: some View {
        ScrollView {
            HStack {
                ZStack {
                    movie.backgroundColor
                        .frame(width: 60, height: 60)
                        .cornerRadius(12)

                    Image(movie.image)
                        .resizable()
                        .frame(width: 50, height: 50)
                        .padding()
                }

                VStack(alignment: .leading) {
                    Text(movie.name)
                        .fontWeight(.bold)

                    Text(movie.category)
                        .font(.subheadline)
                        .fontWeight(.semibold)
                        .foregroundColor(.secondary)

                    Text(movie.description)
                        .fontWeight(.light)
                        .foregroundColor(Color.gray)
                }
            }
            .padding()
        }
    }
}

struct DetailMovieView_Previews: PreviewProvider {
    static var previews: some View {
        DetailMovieView(movie: Movie(
            image: "titanic",
            name: "Titanic",
            category: "Film",
            genre: "Romance",
            backgroundColor: .white,
            description: "Titanic, film de romance où deux amants se rencontrent à bord d'un paquebot légendaire."
        ))
    }
}
*/
/*
 import SwiftUI
 import AVKit

 struct DetailMovieView: View {
     var movie: Movie
     
     var body: some View {
         ScrollView {
             VStack(alignment: .leading) {
                 // VideoPlayer
                 if let videoURL = URL(string: "https://yoursite.com/video.mp4") {
                     VideoPlayer(player: AVPlayer(url: videoURL))
                         .frame(height: 400)
                         .cornerRadius(12)
                         .padding(.bottom, 20)
                 }
                 
                 // Movie details
                 HStack {
                     ZStack {
                         movie.backgroundColor
                             .frame(width: 60, height: 60)
                             .cornerRadius(12)
                         
                         Image(movie.image)
                             .resizable()
                             .frame(width: 50, height: 50)
                     }
                     
                     VStack(alignment: .leading) {
                         Text(movie.name)
                             .fontWeight(.bold)
                             .font(.title)
                         
                         Text(movie.category)
                             .font(.subheadline)
                             .foregroundColor(.secondary)
                         
                         Text(movie.description)
                             .fontWeight(.light)
                             .foregroundColor(Color.gray)
                             .padding(.top, 5)
                     }
                 }
                 .padding()
             }
         }
     }
 }

 struct DetailMovieView_Previews: PreviewProvider {
     static var previews: some View {
         DetailMovieView(movie: Movie(
             image: "titanic",
             name: "Titanic",
             category: "Film",
             genre: "Romance",
             backgroundColor: .white,
             description: "Titanic, film de romance où deux amants se rencontrent à bord d'un paquebot légendaire."
         ))
     }
 }

 */

/* import SwiftUI

struct DetailMovieView: View {
    var movie: Movie

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                // Image du film
                Image(movie.image)
                    .resizable()
                    .scaledToFit()
                    .frame(height: 200)
                    .cornerRadius(12)
                    .padding()

                // Nom et genre
                VStack(alignment: .leading, spacing: 10) {
                    Text(movie.name)
                        .font(.largeTitle)
                        .fontWeight(.bold)

                    Text(movie.genre)
                        .font(.title2)
                        .foregroundColor(.secondary)
                }
                .padding(.horizontal)
                
                // Description
                Text(movie.description)
                    .fontWeight(.light)
                    .foregroundColor(Color.gray)
                    .padding(.top, 5)

                // Bande-annonce
                if let url = URL(string: movie.trailerURL) {
                    VStack(alignment: .center) {
                        Text("Bande-annonce")
                            .font(.headline)
                            .padding(.bottom, 5)

                        WebView(url: url)
                            .frame(height: 250)
                            .cornerRadius(12)
                            .padding(.horizontal)
                    }
                }
            }
        }
        .navigationTitle(movie.name)
    }
}

struct DetailMovieView_Previews: PreviewProvider {
    static var previews: some View {
        DetailMovieView(movie: movies[0]) // Exemple avec le premier film
    }
}
*/

import SwiftUI

struct DetailMovieView: View {
    var movie: Movie

    var body: some View {
        VStack(spacing: 20) {
            // Image du film
            Image(movie.image)
                .resizable()
                .scaledToFit()
                .frame(height: 200)
                .cornerRadius(12)
                .padding()

            // Nom et genre
            VStack(alignment: .leading, spacing: 10) {
                Text(movie.name)
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(Color.black)

                Text(movie.genre)
                    .font(.title2)
                    .foregroundColor(.secondary)
            }
            .padding(.horizontal)
            
            // Description
            Text(movie.description)
                .fontWeight(.light)
                .foregroundColor(Color.gray)
                .padding(.top, 5)

            // Bande-annonce
            if let url = URL(string: movie.trailerURL) {
                VStack(alignment: .center) {
                    Text("Bande-annonce")
                        .font(.headline)
                        .foregroundColor(Color.black)
                        .padding(.bottom, 5)

                    WebView(url: url)
                        .frame(height: 250) // Fixer la taille de la vidéo sans scroll
                        .cornerRadius(12)
                        .padding(.horizontal)
                }
            }
        }
        .navigationTitle(movie.name)
        .padding() // Ajoute un peu de padding global pour éviter que le contenu touche les bords
    }
}

struct DetailMovieView_Previews: PreviewProvider {
    static var previews: some View {
        DetailMovieView(movie: movies[0]) // Exemple avec le premier film
    }
}

