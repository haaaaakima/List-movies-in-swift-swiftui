import SwiftUI

struct LandingScreenView: View {
    var body: some View {
        TabView {
            // Page d'accueil
            NavigationStack {
                VStack {
                    Text("Bienvenue sur l'application de découverte de films")
                        .font(.largeTitle)
                        .multilineTextAlignment(.center)
                        .padding()

                    Text("Découvrez une sélection de bandes annonces incroyable de films, séries, mangas et plus encore !")
                        .font(.body)
                        .multilineTextAlignment(.center)
                        .padding()
                }
                .navigationTitle("Accueil")
            }
            .tabItem {
                Label("Accueil", systemImage: "house.fill")
            }
            
            // Page catégories
            CategoryView()
                .tabItem {
                    Label("Catégories", systemImage: "list.dash")
                }
            
            // Page films
            NavigationStack {
                MovieView()
            }
            .tabItem {
                Label("Films", systemImage: "film")
            }
        }
    }
}

#Preview {
    LandingScreenView()
}
