import Foundation
import SwiftUI

struct Movie: Identifiable {
    var id = UUID()
    var image: String
    var name: String
    var category: String
    var genre: String
    var backgroundColor: Color
    var description: String
    var trailerURL: String
}


var movies = [
    // Films
    Movie(image: "titanic",
          name: "Titanic",
          category: "Film",
          genre: "Romance",
          backgroundColor: .blue,
          description: "Titanic, film de romance où deux amants se rencontrent à bord d'un paquebot légendaire.",
          trailerURL: "https://www.youtube.com/watch?v=wO44qBPBG4c"),
    Movie(image: "harrypotter",
          name: "Harry Potter",
          category: "Film",
          genre: "Science-Fiction",
          backgroundColor: .blue,
          description: "Un thriller captivant explorant les rêves et la magie.",
          trailerURL: "https://www.youtube.com/watch?v=VyHV0BRtdxo"),

    // Mangas
    Movie(image: "onepiece",
          name: "One Piece",
          category: "Manga",
          genre: "Aventure",
          backgroundColor: .orange,
          description: "Luffy et son équipage cherchent le One Piece, un trésor légendaire.",
          trailerURL: "https://www.youtube.com/watch?v=MCb13lbVGE0"),

    Movie(image: "naruto",
          name: "Naruto",
          category: "Manga",
          genre: "Action",
          backgroundColor: .orange,
          description: "L'histoire d'un ninja aspirant à devenir Hokage.",
          trailerURL: "https://www.youtube.com/watch?v=QczGoCmX-pI"),

    // Séries
    Movie(image: "breakingbad",
          name: "Breaking Bad",
          category: "Série",
          genre: "Drame",
          backgroundColor: .green,
          description: "Un professeur de chimie devient fabricant de méthamphétamine.",
          trailerURL: "https://www.youtube.com/watch?v=HhesaQXLuRY"),

    Movie(image: "strangerthings",
          name: "Stranger Things",
          category: "Série",
          genre: "Science-Fiction",
          backgroundColor: .green,
          description: "Des enfants explorent les mystères d'une petite ville.",
          trailerURL: "https://www.youtube.com/watch?v=b9EkMc79ZSU"),
    
    // Animations
    Movie(image: "reinedesneiges",
          name: "La reine des Neiges",
          category: "Animation",
          genre: "Fantastique",
          backgroundColor: .purple,
          description: "Deux soeurs traversent un monde magique.",
          trailerURL: "https://www.youtube.com/watch?v=TbQm5doF_Uc"),

    Movie(image: "simpsons",
          name: "Les Simpsons",
          category: "Animation",
          genre: "Comédie",
          backgroundColor: .purple,
          description: "Une famille hors du commun.",
          trailerURL: "https://www.youtube.com/watch?v=XPG0MqIcby8"),

    // Dramas coréens
    Movie(image: "crashlandingonyou",
          name: "Crash Landing on You",
          category: "Drama Coréen",
          genre: "Romance",
          backgroundColor: .red,
          description: "Une héritière sud-coréenne atterrit accidentellement en Corée du Nord.",
          trailerURL: "https://www.youtube.com/watch?v=8AcNEVUzV4o"),

    Movie(image: "goblin",
          name: "Goblin",
          category: "Drama Coréen",
          genre: "Fantastique",
          backgroundColor: .red,
          description: "Un gobelin immortel cherche son destin et sa fiancée humaine.",
    trailerURL: "https://www.youtube.com/watch?v=8AcNEVUzV4o"),
]
