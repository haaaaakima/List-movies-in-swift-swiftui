import SwiftUI
/*
struct MovieView: View {
    var body: some View {
        NavigationStack{
            VStack {
                List(movies){movie in
                    NavigationLink {
                        DetailMovieView(movie: movie)
                    } label: {
                        HStack {
                            DetailMovieView(movie: movie)
                        }
                        .padding(.vertical, 5)                    }
                }
                .navigationTitle("Films +")
            }
        }
    }
}
*/
#Preview {
    MovieView()
}

import SwiftUI

struct MovieView: View {
    var body: some View {
        NavigationStack{
            ScrollView {
            VStack(alignment: .leading, spacing: 3) {
                ForEach(movies){movie in
                    NavigationLink {
                        DetailMovieView(movie: movie)
                    } label: {
                        HStack {
                            DetailMovieView(movie: movie)
                        }
                    }
                }
                .navigationTitle("Films +")
            }
        }
        }
        }
    }

#Preview {
    MovieView()
}
